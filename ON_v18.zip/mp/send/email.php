<?php



////////////////////////////// OniMa V18 /////////////////////////////

# Change This !!
// <palp4y@yandex.com>




$yourmail = 'palp4y@yandex.com';





// <palp4y@yandex.com>
/*
<<<<<<<<<<<<<<<<<< That's All for you ! Good Boy >>>>>>>>>>>>>>>>>>>>
*/

?>